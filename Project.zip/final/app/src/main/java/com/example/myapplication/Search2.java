package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Search2 extends AppCompatActivity {
    //EditText receiver_msg;
    Button btn;
    DB db = new DB(this);
    ListView list;
    String ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search2);
        Intent intent = getIntent();
        ID = intent.getStringExtra("message_key");
        list = (ListView) findViewById(R.id.list);
        btn = (Button) findViewById(R.id.s_button);
        show();
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click_home();
            }
        });

    }
    private void show(){
        ArrayList<String> listData = db.findteammatchs(ID);
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listData);
        list.setAdapter(arrayAdapter);
    }
    public void click_home(){
        Intent in = new Intent(this,MainActivity.class);
        startActivity(in);
    }
}