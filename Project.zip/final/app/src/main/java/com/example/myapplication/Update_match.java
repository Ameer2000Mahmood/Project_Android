package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Update_match extends AppCompatActivity {
    EditText add_date;
    EditText add_city;
    EditText add_team1;
    EditText add_team2;
    EditText add_num1;
    EditText add_num2;
    EditText id;
    String ID,T1,T2;
    DB db = new DB(this);
    boolean flag=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_match);

        add_date = (EditText) findViewById(R.id.add_date);
        add_city = (EditText) findViewById(R.id.add_city);
        add_team1= (EditText) findViewById(R.id.add_team1);
        add_team2 = (EditText) findViewById(R.id.add_team2);
        add_num1 = (EditText) findViewById(R.id.add_numgoals1);
        add_num2 = (EditText) findViewById(R.id.add_numgoals2);
        id = (EditText) findViewById(R.id.IDinput);

    }

    public void btn_update(View view){
        if(flag) {
            String Date = add_date.getText().toString();
            String City = add_city.getText().toString();
            String Team1 = add_team1.getText().toString();
            String Team2 = add_team2.getText().toString();
            String num_goals1 = add_num1.getText().toString();
            String num_goals2 = add_num2.getText().toString();
            String idteam1 = db.findid(Team1);
            String idteam2 = db.findid(Team2);
            boolean res1 = db.delteammatch(idteam1,ID);
            if(!res1){
                idteam1 = db.findid(T1);
                res1 = db.delteammatch(idteam1,ID);
            }
            boolean res2 = db.delteammatch(idteam2,ID);
            if(!res2){
                idteam2 = db.findid(T2);
                res1 = db.delteammatch(idteam2,ID);
            }
            int num1 = Integer.parseInt(num_goals1), num2 = Integer.parseInt(num_goals2);
            boolean result = db.update_data(ID,Date,City,Team1,Team2,num_goals1,num_goals2);
            int w = 0,l = 0,d = 0, p = 0, q = 0;
            if(num1>num2){w++;p = 3;}else if(num1<num2){l++;}else{d++;p = 1;}
            boolean result2 = db.update_team(Team1,num1,num2,w,l,d,p);
            w = 0;l = 0;d = 0;p = 0; q = 0;
            if(num2>num1){w++;p = 3;}else if(num1>num2){l++;}else{d++;p = 1;}
            boolean result3 = db.update_team(Team2,num2,num1,w,l,d,p);
            if(result && result2 && result3 && res1 && res2) {
                Toast.makeText(Update_match.this,"Update successfully",Toast.LENGTH_SHORT).show();
                add_date.setText("");
                add_city.setText("");
                add_team1.setText("");
                add_team2.setText("");
                add_num1.setText("");
                add_num2.setText("");
                id.setText("");
                ((View) findViewById(R.id.add_date)).setVisibility(View.GONE);
                ((View) findViewById(R.id.add_city)).setVisibility(View.GONE);
                ((View) findViewById(R.id.add_team1)).setVisibility(View.GONE);
                ((View) findViewById(R.id.add_team2)).setVisibility(View.GONE);
                ((View) findViewById(R.id.add_numgoals1)).setVisibility(View.GONE);
                ((View) findViewById(R.id.add_numgoals2)).setVisibility(View.GONE);
                ((View) findViewById(R.id.IDinput)).setVisibility(View.VISIBLE);
                flag = false;
                return;
            }

        }
        ID = id.getText().toString();
        Cursor cursor = db.find(ID);
        if (cursor.getCount()>0){



            flag=true;
            ((View) findViewById(R.id.add_date)).setVisibility(View.VISIBLE);
            ((View) findViewById(R.id.add_city)).setVisibility(View.VISIBLE);
            ((View) findViewById(R.id.add_team1)).setVisibility(View.VISIBLE);
            ((View) findViewById(R.id.add_team2)).setVisibility(View.VISIBLE);
            ((View) findViewById(R.id.add_numgoals1)).setVisibility(View.VISIBLE);
            ((View) findViewById(R.id.add_numgoals2)).setVisibility(View.VISIBLE);
            ((View) findViewById(R.id.IDinput)).setVisibility(View.GONE);
            cursor.moveToFirst();
            String s1 = cursor.getString(6);
            String s2 = cursor.getString(1);
            String s3 = cursor.getString(2);
            String s4 = cursor.getString(3);
            String s5 = cursor.getString(4);
            String s6 = cursor.getString(5);
            T1 = s4; T2 = s5;
            add_date.setText(s2, TextView.BufferType.EDITABLE);
            add_city.setText(s3, TextView.BufferType.EDITABLE);
            add_team1.setText(s4, TextView.BufferType.EDITABLE);
            add_team2.setText(s5, TextView.BufferType.EDITABLE);
            add_num1.setText(s6, TextView.BufferType.EDITABLE);
            add_num2.setText(s1, TextView.BufferType.EDITABLE);

        }
        else {

            Toast.makeText(Update_match.this," oOps failure update!! no like this id",Toast.LENGTH_SHORT).show();
        }

    }

}