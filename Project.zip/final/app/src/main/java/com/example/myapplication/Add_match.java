package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.SQLData;
import java.util.LinkedList;

public class Add_match extends AppCompatActivity {
    EditText add_date;
    EditText add_city;
    EditText add_team1;
    EditText add_team2;
    EditText add_num1;
    EditText add_num2;
    DB db = new DB(this);
    Button ADD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_match);

        add_date = (EditText) findViewById(R.id.add_date);
        add_city = (EditText) findViewById(R.id.add_city);
        add_team1= (EditText) findViewById(R.id.add_team1);
        add_team2 = (EditText) findViewById(R.id.add_team2);
        add_num1 = (EditText) findViewById(R.id.add_numgoals1);
        add_num2 = (EditText) findViewById(R.id.add_numgoals2);
    }

    public void btn_add_data(View view){
        String Date = add_date.getText().toString();
        String City = add_city.getText().toString();
        String Team1 = add_team1.getText().toString();
        String Team2 = add_team2.getText().toString();
        Integer num_goals1 = Integer.parseInt(String.valueOf(add_num1.getText()));
        Integer num_goals2 = Integer.parseInt(String.valueOf(add_num2.getText()));

        Boolean result = db.insert_data(Date,City,Team1,Team2,num_goals1,num_goals2);
        if (result == true){
            Toast.makeText(Add_match.this,"add successfully",Toast.LENGTH_SHORT).show();
            add_date.setText("");
            add_city.setText("");
            add_team1.setText("");
            add_team2.setText("");
            add_num1.setText("");
            add_num2.setText("");
            int w = 0,l = 0,d = 0, p = 0, q = 0;
            if(num_goals1>num_goals2){w++;p = 3;}else if(num_goals1<num_goals2){l++;q = 3;}else{d++;p = 1;q = 1;}

            boolean updated1 = db.update_team(Team1,num_goals1,num_goals2,w,l,d,p);
            boolean updated2 = db.update_team(Team2,num_goals2,num_goals1,l,w,d,q);
            if(updated1){
                Toast.makeText(Add_match.this,"successfully updated 1",Toast.LENGTH_SHORT).show();
            }else{
                boolean inserted = db.insert_data2(Team1,num_goals1,num_goals2,w,l,d,p);
                if(inserted){
                    Toast.makeText(Add_match.this,"successfully inserted team1",Toast.LENGTH_SHORT).show();
                }
            }
            if(updated2){
                Toast.makeText(Add_match.this,"successfully updated 2",Toast.LENGTH_SHORT).show();
            }else{
                boolean inserted2 = db.insert_data2(Team2,num_goals2,num_goals1,l,w,d,q);
                if(inserted2){
                    Toast.makeText(Add_match.this,"successfully inserted team2",Toast.LENGTH_SHORT).show();
                }
            }
        }
        else {
            Toast.makeText(Add_match.this,"failed add!!",Toast.LENGTH_SHORT).show();
        }

    }
}