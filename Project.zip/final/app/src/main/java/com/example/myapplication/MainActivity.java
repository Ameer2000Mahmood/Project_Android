package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button update_match;
    Button remove_match;
    Button list_teams;
    Button search;
    Button add_match;
    Button list_match;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //update match
        update_match = findViewById(R.id.update);
        update_match.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click_update();
            }
        });
        // add match button
        add_match = findViewById(R.id.add_match);
        add_match.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click_add();

            }
        });

        // remove click
        remove_match = findViewById(R.id.remove);
        remove_match.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click_remove();
            }
        });

        // LIST CLICK
        list_match = findViewById(R.id.list);
        list_match.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click_list();
            }
        });

        // table CLICK
        list_teams = findViewById(R.id.table);
        list_teams.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click_table();
            }
        });
        // search CLICK
        search = findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click_search();
            }
        });

    }


    void click_add(){
        Intent in = new Intent(this,Add_match.class);
        startActivity(in);

    }
    void click_update(){
        Intent in = new Intent(this,Update_match.class);
        startActivity(in);
    }
    void click_table(){
        Intent in = new Intent(this,Table.class);
        startActivity(in);
    }
    void click_list(){
        Intent in = new Intent(this,List.class);
        startActivity(in);
    }

    void click_search(){
        Intent in = new Intent(this,Search.class);
        startActivity(in);
    }

    void click_remove(){
        Intent in = new Intent(this,Remove_match.class);
        startActivity(in);
    }






}