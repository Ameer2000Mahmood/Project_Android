package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Table extends AppCompatActivity {


    DB db = new DB(this);
    ListView list;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table);
        list = (ListView) findViewById(R.id.table);


        ShowData();
    }


    public void ShowData(){
        ArrayList<String> listData = db.getAll_t();
        listData = sorttable(listData);
        listData = indextable(listData);
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listData);
        list.setAdapter(arrayAdapter);


    }
    private ArrayList<String> sorttable(ArrayList<String> arr)
    {
        int i,j,t,x1,x2;
        String s1, s2,s3,s4;
        char ch;
        for (i=1;i<arr.size()-1;i++)
        {
            for(j=i+1;j<arr.size();j++)
            {
                s3="";s4="";
                s1 = arr.get(i); s2 = arr.get(j);
                t=s1.length()-1;
                while(s1.charAt(t) != ' ')
                {
                    s3+=s1.charAt(t);
                    t--;
                }
                t=s2.length()-1;
                while(s2.charAt(t) != ' ')
                {
                    s4+=s2.charAt(t);
                    t--;
                }
                s1="";s2="";
                for (int x=0; x<s3.length(); x++)
                {
                    ch= s3.charAt(x); //extracts each character
                    s1= ch+s1; //adds each character in front of the existing string
                }
                for (int x=0; x<s4.length(); x++)
                {
                    ch= s4.charAt(x); //extracts each character
                    s2= ch+s2; //adds each character in front of the existing string
                }
                x1 = Integer.parseInt(s1); x2= Integer.parseInt(s2);
                if(x1<x2)
                {
                    s1 = arr.get(j);
                    arr.set(j,arr.get(i));
                    arr.set(i,s1);
                }

            }
        }
        return  arr;
    }

    private ArrayList<String> indextable(ArrayList<String> arr){
        int i,x=1,j=0;
        String s1="";
        for(i=1;i<arr.size();i++){
            s1 = arr.get(i);
            while(s1.charAt(j)!=':')
                j++;
            j++;
            s1 = s1.substring(0,j) + ""+ x + s1.substring(j);
            arr.set(i,s1);
            x++;
            j=0;
        }
        return  arr;
    }
}

