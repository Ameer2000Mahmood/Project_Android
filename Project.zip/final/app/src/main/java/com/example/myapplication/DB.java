package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DB extends SQLiteOpenHelper {
    public static final String DB_name = "DATABASE.db";
    public final String table1 = "matches";
    public final String table2 = "teams";

    public DB(@Nullable Context context) {
        super(context, DB_name, null, 2);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+ table1 +"(id INTEGER PRIMARY KEY AUTOINCREMENT,DATE TEXT , CITY TEXT ,team1 TEXT , team2 TEXT , num_goals1 INTEGER,num_goals2 INTEGER )");
        db.execSQL("CREATE TABLE "+ table2 +"(id INTEGER PRIMARY KEY AUTOINCREMENT,TEAM TEXT ,TOTAL_SCORED_GOALS INTEGER,TOTAL_RECEIVED_GOALS INTEGER,WINS INTEGER,LOSES INTEGER,DRAW INTEGER,POINTS INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+table1);
        db.execSQL("DROP TABLE IF EXISTS "+table2);
        onCreate(db);
    }

    //insert new match
    public boolean insert_data(String date, String city, String team1, String team2, Integer goal1, Integer goal2) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("DATE", date);
        contentValues.put("CITY", city);
        contentValues.put("team1", team1);
        contentValues.put("team2", team2);
        contentValues.put("num_goals1", goal1);
        contentValues.put("num_goals2", goal2);

        long result = db.insert(table1, null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
    public Cursor getteams(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM teams", null);
        return cursor ;
    }

    // insert new team
    public boolean insert_data2(String TEAM, Integer TOTAL_SCORED_GOALS, Integer TOTAL_RECEIVED_GOALS, Integer TOTAL_WIN, Integer TOTAL_LOSE, Integer DRAW, Integer POINTS) {

        //search team first

        // if does not exist then add to db
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("TEAM", TEAM);
        contentValues.put("TOTAL_SCORED_GOALS", TOTAL_SCORED_GOALS);
        contentValues.put("TOTAL_RECEIVED_GOALS", TOTAL_RECEIVED_GOALS);
        contentValues.put("WINS", TOTAL_WIN);
        contentValues.put("LOSES", TOTAL_LOSE);
        contentValues.put("DRAW", DRAW);
        contentValues.put("POINTS", POINTS);

        long result = db.insert(table2, null, contentValues);
        if (result == -1) {
            return false;
        } else {

            return true;
        }

    }

    //update match
    public boolean update_data(String id,String date, String city, String team1, String team2, String goal1, String goal2) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("DATE", date);
        contentValues.put("CITY", city);
        contentValues.put("team1", team1);
        contentValues.put("team2", team2);
        contentValues.put("num_goals1", goal1);
        contentValues.put("num_goals2", goal2);

        db.update(table1,contentValues,"id=?",new String[]{id});

        return true;
    }

    public Cursor find(String id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM matches where id = ?", new String[]{id});
        cursor.moveToFirst();
        Cursor cursor1 = db.rawQuery("SELECT * FROM matches", null);
        return cursor;
    }
    public String findid(String name)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM teams",null);
        cursor.moveToFirst();
        while (cursor.isAfterLast() == false) {
            if(cursor.getString(1).equals(name))
                return cursor.getString(0);
            cursor.moveToNext();
        }
        return  "-1";
    }
    public Cursor findteam(String id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM teams where id = ?", new String[]{id});
        cursor.moveToFirst();
        return cursor;
    }

    //TEAM TEXT ,TOTAL_SCORED_GOALS INTEGER,TOTAL_RECEIVED_GOALS INTEGER,WINS INTEGER,LOSES INTEGER,DRAW INTEGER,POINTS INTEGER
    public boolean delteammatch(String idteam, String idmatch){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = findteam(idteam);
        Cursor crs = find(idmatch);
        int x;
        if(cursor.getCount()>0 && crs.getCount()>0)
        {
            cursor.moveToFirst();
            crs.moveToFirst();
            ContentValues contentValues = new ContentValues();
            // 3 4
            //DATE TEXT , CITY TEXT ,team1 TEXT , team2 TEXT , num_goals1 INTEGER,num_goals2 INTEGER
            String st1 = cursor.getString(1), st2=crs.getString(3), st3= crs.getString(4);
            if(st1.equals(st2))
            {
                if(Integer.parseInt(crs.getString(5))>Integer.parseInt(crs.getString(6)))
                {
                    x=1;
                }
                else if(Integer.parseInt(crs.getString(5))<Integer.parseInt(crs.getString(6)))
                    x=2;
                else x=3;
                int x1=Integer.parseInt(cursor.getString(2)), x2 = Integer.parseInt(crs.getString(5)),x3;
                x3 = x1-x2;
                contentValues.put("TOTAL_SCORED_GOALS",x3);
                x1=Integer.parseInt(cursor.getString(3)); x2 = Integer.parseInt(crs.getString(6));
                x3 = x1-x2;
                contentValues.put("TOTAL_RECEIVED_GOALS",x3);
                if(x==1)
                {
                    x3 = Integer.parseInt(cursor.getString(4))-1;
                    contentValues.put("WINS",x3);
                    x3 = Integer.parseInt(cursor.getString(7))-3;
                    contentValues.put("POINTS",x3);
                }
                else if(x==2)
                {
                    x3 = Integer.parseInt(cursor.getString(5))-1;
                    contentValues.put("LOSES",x3);
                   // contentValues.put("POINTS",Integer.parseInt(cursor.getString(7))-1);
                }
                else{
                    contentValues.put("DRAW",Integer.parseInt(cursor.getString(6))-1);
                    contentValues.put("POINTS",Integer.parseInt(cursor.getString(7))-1);
                }
                db.update(table2,contentValues,"id=?",new String[]{idteam});
                return true;
            }
            else if(st1.equals(st3))
            {
                String st = cursor.getString(1);
                if(Integer.parseInt(crs.getString(5))>Integer.parseInt(crs.getString(6)))
                {
                    x=2;
                }
                else if(Integer.parseInt(crs.getString(5))<Integer.parseInt(crs.getString(6)))
                    x=1;
                else x=3;
                int x2;
                x2=Integer.parseInt(cursor.getString(2))-Integer.parseInt(crs.getString(6));
                contentValues.put("TOTAL_SCORED_GOALS",x2);
                x2 = Integer.parseInt(cursor.getString(3))-Integer.parseInt(crs.getString(5));
                contentValues.put("TOTAL_RECEIVED_GOALS",x2);
                if(x==1)
                {
                    x2 = Integer.parseInt(cursor.getString(4));
                    x2=x2-1;
                    contentValues.put("WINS",x2);
                    x2 = Integer.parseInt(cursor.getString(7));
                    x2-=3;
                    contentValues.put("POINTS",x2);
                }
                else if(x==2)
                {
                    x2 = Integer.parseInt(cursor.getString(5));
                    x2--;
                    contentValues.put("LOSES",x2);

                }
                else{
                    x2 = Integer.parseInt(cursor.getString(6))-1;
                    contentValues.put("DRAW",x2);
                    x2 = Integer.parseInt(cursor.getString(7))-1;
                    contentValues.put("POINTS",x2);
                }
                db.update(table2,contentValues,"id=?",new String[]{idteam});
                return true;
            }
        }
        return false;
    }

    public ArrayList findteammatchs(String id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList arrayList = new ArrayList();
        Cursor cursor = db.rawQuery("SELECT * FROM teams where id = ?", new String[]{id});
        cursor.moveToFirst();
        String name = cursor.getString(1);
        Cursor res = db.rawQuery("select * from "+table1, null);
        res.moveToFirst();
        while (res.isAfterLast() == false) {

            String s1 = res.getString(0);
            String s2 = res.getString(1);
            String s3 = res.getString(2);
            String s4 = res.getString(3);
            String s5 = res.getString(4);
            String s6 = res.getString(5);
            String s7 = res.getString(6);

            if(s5.equals(name) || s4.equals(name)) {
                //DATE TEXT , CITY TEXT ,team1 TEXT , team2 TEXT , num_goals1 INTEGER,num_goals2 INTEGER
                arrayList.add(s1 + " : " + s2 + "  " + s3 + "  " + s4 + " " + s5 + " " + s6 + " " + s7);
            }
            res.moveToNext();
        }
        return arrayList;
    }
    //update team
    public boolean update_team(String team, Integer s_g, Integer r_g , Integer w , Integer l ,Integer d,  Integer p) {
        SQLiteDatabase db = this.getWritableDatabase();
        int x;
        try {
            Cursor cursor = db.rawQuery("SELECT * FROM teams where TEAM = ?", new String[]{team});
            if(cursor.getCount()>0){

                cursor.moveToFirst();
                ContentValues contentValues = new ContentValues();
                x = s_g+Integer.parseInt(cursor.getString(2));
                contentValues.put("TOTAL_SCORED_GOALS",x);
                x = r_g+Integer.parseInt(cursor.getString(3));
                contentValues.put("TOTAL_RECEIVED_GOALS",x);
                x = w+Integer.parseInt(cursor.getString(4));
                contentValues.put("WINS",x);
                x = l+Integer.parseInt(cursor.getString(5));
                contentValues.put("LOSES",x);
                x =  d+Integer.parseInt(cursor.getString(6));
                contentValues.put("DRAW",x);
                x = p+Integer.parseInt(cursor.getString(7));
                contentValues.put("POINTS",x);
                long res = db.update(table2,contentValues,"TEAM = ?",new String[]{team});
                if(res == -1){
                    return false;
                }else { return true ;}
            }
        }catch(Exception e){
            return false ;
        }

        // false = didn't updated
        return false;
    }

    //get all matches
    public ArrayList getAll() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from "+table1, null);
        int x=1,w,l,d,t=0; //String s = "ID : #  Team Matches iGoal oGoal Win Lose Draw Points";
        //TEAM TEXT ,TOTAL_SCORED_GOALS INTEGER,TOTAL_RECEIVED_GOALS INTEGER,WINS INTEGER,LOSES INTEGER,DRAW INTEGER,POINTS

        res.moveToFirst();
        while (res.isAfterLast() == false) {
            if(x==1)
            {
                arrayList.add("ID : Date City  Team1 Team2 Goals");
            }
            String s1 = res.getString(0);
            String s2 = res.getString(1);
            String s3 = res.getString(2);
            String s4 = res.getString(3);
            String s5 = res.getString(4);
            String s6 = res.getString(5);
            String s7 = res.getString(6);
            arrayList.add(s1 + " : "  + s2  +"  " + s3 + "  " + s4 + " " + s5 + " " + s6 + "-" + s7);
            res.moveToNext();
            x++;
        }

        return arrayList;
    }

    //get all teams
    public ArrayList getAll_t() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        int x=1;String s = "ID : #  Team Matches iGoal oGoal Win Lose Draw Points";
        Cursor res = db.rawQuery("select * from "+table2, null);
        res.moveToFirst();
        while (res.isAfterLast() == false) {
            if(x==1)
            {
                arrayList.add(s);
            }
            String s1 = res.getString(0);
            String s2 = res.getString(1);
            String s3 = res.getString(2);
            String s4 = res.getString(3);
            String s5 = res.getString(4);
            String s6 = res.getString(5);
            String s7 = res.getString(6);
            String s8 = res.getString(7);
            int w = Integer.parseInt(res.getString(4));
            int l = Integer.parseInt(res.getString(5));
            int d = Integer.parseInt(res.getString(6));
            arrayList.add(s1 + " : "+  s2 + "  " + (w+l+d) +" " + s3 + "  " + s4 + " " + s5 + " " + s6 + " " + s7 + " " + s8);
            res.moveToNext();
            x++;
        }

        return arrayList;
    }










    public void deleteAll() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(table1, null, null);
        db.execSQL("delete from " + table1);
        db.delete(table2, null, null);
        db.execSQL("delete from " + table2);


        db.close();
    }

    public Integer Delete(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        return  db.delete(table1,"id=?",new String[]{id});
    }

    public boolean isEmpty(String TableName){

        SQLiteDatabase database = this.getReadableDatabase();
        long NoOfRows = DatabaseUtils.queryNumEntries(database,TableName);

        if (NoOfRows == 0){
            return true;
        } else {
            return false;
        }
    }

}
