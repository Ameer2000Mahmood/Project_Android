package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Remove_match extends AppCompatActivity {
    DB db = new DB(this);
    EditText id;
    Cursor cursor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_match);
        id = (EditText) findViewById(R.id.IDinput);
    }

    public void btn_remove(View view){
        String ID = id.getText().toString();
        cursor = db.find(ID);
        String idteam1 = cursor.getString(3);
        String idteam2 = cursor.getString(4);
        idteam1 = db.findid(idteam1);
        idteam2 = db.findid(idteam2);
        boolean res1 = db.delteammatch(idteam1,ID);
        boolean res2 = db.delteammatch(idteam2,ID);
        Integer res = db.Delete(ID);
        if (res > 0 && res1 && res2){
            Toast.makeText(Remove_match.this,"delete successfully",Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(Remove_match.this,"delete fail:(",Toast.LENGTH_SHORT).show();
        }
        id.setText("");
    }
}